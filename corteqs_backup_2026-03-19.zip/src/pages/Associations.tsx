import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Users, MapPin, Calendar as CalendarIcon, GraduationCap, Radio, Tv, Music, Landmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CountryFilter from "@/components/CountryFilter";
import { associations } from "@/data/mock";

const typeFilters = [
  { key: "all", label: "Tümü" },
  { key: "dernek", label: "Dernekler & Vakıflar" },
  { key: "diplomatik", label: "🏛️ Büyükelçilik & Konsolosluk" },
  { key: "okul", label: "🎓 Türk Okulları" },
  { key: "radyo", label: "📻 Radyolar" },
  { key: "tv", label: "📺 TV Kanalları" },
];

const Associations = () => {
  const [country, setCountry] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const filtered = associations.filter((a) => {
    const matchesCountry = country === "all" || a.country === country;
    const matchesType = typeFilter === "all"
      || (typeFilter === "dernek" && ["Dernek", "Vakıf", "İş Örgütü", "Sosyal Örgüt"].includes(a.type))
      || (typeFilter === "diplomatik" && ["Büyükelçilik", "Konsolosluk"].includes(a.type))
      || (typeFilter === "okul" && a.type === "Okul")
      || (typeFilter === "radyo" && a.type === "Radyo")
      || (typeFilter === "tv" && a.type === "TV Kanalı");
    return matchesCountry && matchesType;
  });

  const typeColors: Record<string, string> = {
    "Dernek": "bg-primary/10 text-primary",
    "Vakıf": "bg-turquoise/10 text-turquoise",
    "İş Örgütü": "bg-gold/10 text-gold",
    "Sosyal Örgüt": "bg-primary/10 text-primary",
    "Okul": "bg-success/10 text-success",
    "Radyo": "bg-purple-500/10 text-purple-600",
    "TV Kanalı": "bg-destructive/10 text-destructive",
    "Büyükelçilik": "bg-secondary text-secondary-foreground",
    "Konsolosluk": "bg-secondary text-secondary-foreground",
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground">Kuruluşlar</h1>
              <p className="text-muted-foreground font-body mt-1">
                {filtered.length} kuruluş bulundu
              </p>
            </div>
            <CountryFilter value={country} onChange={setCountry} />
          </div>

          {/* Type filter tabs */}
          <div className="flex flex-wrap gap-2 mb-8">
            {typeFilters.map((f) => (
              <Button
                key={f.key}
                variant={typeFilter === f.key ? "default" : "outline"}
                size="sm"
                onClick={() => setTypeFilter(f.key)}
                className="text-xs"
              >
                {f.label}
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((a) => (
              <Link
                to={`/association/${a.id}`}
                key={a.id}
                className="group bg-card rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all duration-300 border border-border hover:-translate-y-1 block"
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center text-secondary-foreground font-bold text-sm shrink-0">
                    {a.logo}
                  </div>
                  <div className="min-w-0">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-semibold mb-1 ${typeColors[a.type] || "bg-primary/10 text-primary"}`}>
                      {a.type}
                    </span>
                    <h3 className="font-bold text-foreground truncate">{a.name}</h3>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground font-body flex items-center gap-1 mb-3">
                  <MapPin className="h-4 w-4 shrink-0" /> {a.city}, {a.country}
                </p>

                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span className="font-body">{a.members.toLocaleString()} {a.type === "Radyo" || a.type === "TV Kanalı" ? "dinleyici" : "üye"}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <CalendarIcon className="h-4 w-4" />
                    <span className="font-body">{a.events} etkinlik</span>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground font-body line-clamp-2 mb-4">{a.description}</p>

                <div className="flex gap-2">
                  <Link to={`/association/${a.id}`} className="flex-1" onClick={(e) => e.stopPropagation()}>
                    <Button variant="default" size="sm" className="w-full">Detay</Button>
                  </Link>
                  {a.type === "Radyo" ? (
                    <Link to={`/radio/${a.id}/song-request`} className="flex-1" onClick={(e) => e.stopPropagation()}>
                      <Button variant="outline" size="sm" className="w-full gap-1">
                        <Music className="h-3 w-3" /> İstek Parça
                      </Button>
                    </Link>
                  ) : ["Büyükelçilik", "Konsolosluk"].includes(a.type) ? (
                    <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}>
                      <CalendarIcon className="h-3 w-3" /> Randevu Al
                    </Button>
                  ) : (
                    <Button variant="outline" size="sm" className="flex-1" onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}>
                      {a.type === "TV Kanalı" ? "İzle" : "Etkinlikler"}
                    </Button>
                  )}
                </div>
              </Link>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-20 text-muted-foreground font-body">
              Bu filtrelerde kuruluş bulunamadı.
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Associations;
