export interface Consultant {
  id: string;
  name: string;
  role: string;
  category: string;
  country: string;
  city: string;
  rating: number;
  reviews: number;
  avatar: string;
  photo: string;
  bio: string;
  website: string;
  whatsapp: string;
  languages: string[];
  specialties: string[];
}

export interface Association {
  id: string;
  name: string;
  type: "Dernek" | "Vakıf" | "İş Örgütü" | "Sosyal Örgüt" | "Okul" | "Radyo" | "TV Kanalı" | "Büyükelçilik" | "Konsolosluk";
  country: string;
  city: string;
  members: number;
  events: number;
  description: string;
  website: string;
  founded: number;
  logo: string;
}

export interface WhatsAppGroup {
  id: string;
  name: string;
  category: "alumni" | "hobi" | "is";
  country: string;
  city: string;
  members: number;
  description: string;
  link: string;
  university?: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  endTime: string;
  country: string;
  city: string;
  location: string;
  type: "online" | "yüz yüze" | "hybrid";
  category: "networking" | "eğitim" | "kültür" | "iş" | "sosyal" | "spor";
  organizer: string;
  organizerType: "consultant" | "association" | "member";
  organizerAvatar: string;
  attendees: number;
  maxAttendees: number;
  price: number;
  featured: boolean;
  image: string;
  tags: string[];
  boosted?: boolean;
  boostExpiry?: string;
}

export interface BoostPackage {
  id: string;
  name: string;
  price: number;
  features: string[];
  estimatedReach: number;
  duration: string;
}

export interface AudienceSegment {
  id: string;
  label: string;
  type: "users" | "whatsapp" | "email";
  matchScore: number;
  size: number;
  category: string;
  description: string;
}

export const boostPackage: BoostPackage = {
  id: "boost-all-in-one",
  name: "Etkinlik Boost Paketi",
  price: 49,
  features: [
    "⭐ Featured etkinliklerde 7 gün yer alma",
    "👥 AI eşleşmeli platform kullanıcılarına tanıtım",
    "💬 İlgili WhatsApp gruplarına duyuru",
    "📧 Kendi mail listenize kampanya gönderimi",
    "📊 Detaylı erişim & tıklama raporu",
  ],
  estimatedReach: 2500,
  duration: "7 gün",
};

export const getAudienceSegments = (eventCategory: string, eventCountry: string): AudienceSegment[] => {
  const segments: AudienceSegment[] = [];

  // AI-matched platform users
  const categoryUserMap: Record<string, { label: string; size: number }> = {
    networking: { label: "Networking & İş ilişkileri ilgili kullanıcılar", size: 1200 },
    eğitim: { label: "Eğitim & kişisel gelişim ilgili kullanıcılar", size: 850 },
    kültür: { label: "Kültür & sanat etkinlikleri takipçileri", size: 640 },
    iş: { label: "İş & kariyer odaklı profesyoneller", size: 1450 },
    sosyal: { label: "Sosyal etkinlik katılımcıları", size: 920 },
    spor: { label: "Spor & outdoor aktivite meraklıları", size: 580 },
  };
  const userMatch = categoryUserMap[eventCategory] || { label: "Genel platform kullanıcıları", size: 500 };
  segments.push({
    id: "users-category",
    label: userMatch.label,
    type: "users",
    matchScore: 92,
    size: userMatch.size,
    category: eventCategory,
    description: `${eventCountry} ve çevresindeki ${userMatch.label.toLowerCase()}`,
  });

  // AI-matched WhatsApp groups
  const categoryGroupMap: Record<string, string[]> = {
    networking: ["Berlin Türk Tech Network", "Londra Türk Girişimciler", "Dubai Türk Finans Grubu"],
    iş: ["Berlin Türk Tech Network", "Londra Türk Girişimciler", "Almanya Türk Sağlık Profesyonelleri"],
    eğitim: ["ODTÜ Mezunları Almanya", "Boğaziçi Mezunları Almanya", "İTÜ Mezunları Almanya"],
    kültür: ["Londra Türk Yemek Kulübü", "Dubai Türk Kitap Kulübü", "Amsterdam Fotoğrafçılık Grubu"],
    sosyal: ["Londra Türk Yemek Kulübü", "Berlin Türk Futbol Grubu", "Münih Doğa & Hiking"],
    spor: ["Berlin Türk Futbol Grubu", "Münih Doğa & Hiking"],
  };
  const matchedGroups = categoryGroupMap[eventCategory] || ["Genel Türk Topluluk Grubu"];
  segments.push({
    id: "whatsapp-groups",
    label: `${matchedGroups.length} WhatsApp grubuna duyuru`,
    type: "whatsapp",
    matchScore: 87,
    size: matchedGroups.length * 280,
    category: eventCategory,
    description: matchedGroups.join(", "),
  });

  // Email list
  segments.push({
    id: "email-list",
    label: "Kendi mail listenize kampanya",
    type: "email",
    matchScore: 95,
    size: 0,
    category: eventCategory,
    description: "Mail listenizi yükleyin veya mevcut abone listenizi kullanın",
  });

  return segments;
};

export const countries = [
  "Almanya", "İngiltere", "Hollanda", "BAE", "ABD", "Fransa", "Avusturya", "İsviçre", "Kanada", "Avustralya", "Katar",
];

export const consultants: Consultant[] = [
  { id: "ayse-kara", name: "Ayşe Kara", role: "Gayrimenkul Danışmanı", category: "Gayrimenkul", country: "İngiltere", city: "Londra", rating: 4.9, reviews: 128, avatar: "AK", photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=face", bio: "10 yıllık deneyimle Londra'da Türk yatırımcılara gayrimenkul danışmanlığı sunuyorum.", website: "https://aysekara.co.uk", whatsapp: "+447700000001", languages: ["Türkçe", "İngilizce"], specialties: ["Yatırım gayrimenkul", "Alım-satım süreçleri", "Proje temsilciliği"] },
  { id: "mehmet-yilmaz", name: "Mehmet Yılmaz", role: "Vize & Göçmenlik", category: "Vize & Göçmenlik", country: "Almanya", city: "Berlin", rating: 4.8, reviews: 95, avatar: "MY", photo: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop&crop=face", bio: "Almanya'da oturum, çalışma izni ve vatandaşlık süreçlerinde uzman danışman.", website: "https://mehmetyilmaz.de", whatsapp: "+491700000002", languages: ["Türkçe", "Almanca", "İngilizce"], specialties: ["Oturum izni", "Yatırımcı vizesi", "Golden Visa"] },
  { id: "elif-demir", name: "Elif Demir", role: "Hukuk Danışmanı", category: "Hukuk & Vergi", country: "Hollanda", city: "Amsterdam", rating: 4.9, reviews: 156, avatar: "ED", photo: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&crop=face", bio: "Uluslararası hukuk ve vergi danışmanlığı. 12 yıllık deneyim.", website: "https://elifdemir.nl", whatsapp: "+316000000003", languages: ["Türkçe", "Hollandaca", "İngilizce"], specialties: ["Sözleşme hukuku", "Vergi avantajları", "Mortgage çözümleri"] },
  { id: "can-ozdemir", name: "Can Özdemir", role: "Finansal Danışman", category: "Finansal", country: "BAE", city: "Dubai", rating: 4.7, reviews: 87, avatar: "CÖ", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face", bio: "Dubai merkezli finansal danışman. Yatırım ve vergi planlaması.", website: "https://canozdemir.ae", whatsapp: "+971500000004", languages: ["Türkçe", "İngilizce", "Arapça"], specialties: ["Yatırım çeşitlendirme", "Döviz planlama", "Vergi optimizasyonu"] },
  { id: "zeynep-arslan", name: "Zeynep Arslan", role: "Şirket Kuruluşu Danışmanı", category: "Şirket & İş", country: "BAE", city: "Dubai", rating: 4.8, reviews: 112, avatar: "ZA", photo: "https://images.unsplash.com/photo-1598550874175-4d0ef436c909?w=400&h=400&fit=crop&crop=face", bio: "Dubai'de free zone ve mainland şirket kuruluşu.", website: "https://zeyneparslan.ae", whatsapp: "+971500000005", languages: ["Türkçe", "İngilizce"], specialties: ["Free zone şirket", "Lisans & muhasebe", "Banka hesap açılışı"] },
  { id: "ali-celik", name: "Ali Çelik", role: "Yaşam & Relocation", category: "Yaşam & Relocation", country: "Almanya", city: "Münih", rating: 4.6, reviews: 64, avatar: "AÇ", photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face", bio: "Almanya'ya taşınan aileler için kapsamlı destek.", website: "https://alicelik.de", whatsapp: "+491700000006", languages: ["Türkçe", "Almanca"], specialties: ["Ev & okul seçimi", "Sağlık sigortası", "Günlük yaşam rehberliği"] },
  { id: "selin-yildiz", name: "Selin Yıldız", role: "Gayrimenkul Danışmanı", category: "Gayrimenkul", country: "ABD", city: "New York", rating: 4.9, reviews: 203, avatar: "SY", photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face", bio: "New York bölgesinde Türk yatırımcılara gayrimenkul danışmanlığı.", website: "https://selinyildiz.com", whatsapp: "+12120000007", languages: ["Türkçe", "İngilizce"], specialties: ["Yatırım gayrimenkul", "Konut alım-satım"] },
  { id: "burak-sahin", name: "Burak Şahin", role: "Hukuk Danışmanı", category: "Hukuk & Vergi", country: "Fransa", city: "Paris", rating: 4.7, reviews: 78, avatar: "BŞ", photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop&crop=face", bio: "Paris'te uluslararası ticaret hukuku ve vergi planlaması.", website: "https://buraksahin.fr", whatsapp: "+33600000008", languages: ["Türkçe", "Fransızca", "İngilizce"], specialties: ["Ticaret hukuku", "Vergi yükümlülükleri", "Sözleşmeler"] },
  { id: "dr-hasan-turk", name: "Dr. Hasan Türk", role: "Doktor - Genel Pratisyen", category: "Yaşam & Relocation", country: "Almanya", city: "Frankfurt", rating: 4.9, reviews: 312, avatar: "HT", photo: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop&crop=face", bio: "Frankfurt'ta Türk hastalar için genel sağlık danışmanlığı.", website: "https://drhasanturk.de", whatsapp: "+491700000009", languages: ["Türkçe", "Almanca"], specialties: ["Genel sağlık", "Sağlık sistemi rehberliği", "Check-up"] },
  { id: "dr-leyla-aydin", name: "Dr. Leyla Aydın", role: "Diş Hekimi", category: "Yaşam & Relocation", country: "İngiltere", city: "Londra", rating: 4.8, reviews: 189, avatar: "LA", photo: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop&crop=face", bio: "Londra'da Türkçe hizmet veren diş hekimi.", website: "https://drleylaaydin.co.uk", whatsapp: "+447700000010", languages: ["Türkçe", "İngilizce"], specialties: ["İmplant", "Estetik diş", "Genel diş sağlığı"] },
  { id: "dr-kemal-oz", name: "Dr. Kemal Öz", role: "Doktor - Dahiliye", category: "Yaşam & Relocation", country: "Hollanda", city: "Rotterdam", rating: 4.7, reviews: 145, avatar: "KÖ", photo: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&h=400&fit=crop&crop=face", bio: "Hollanda'da iç hastalıkları uzmanı.", website: "https://drkemaloz.nl", whatsapp: "+316000000011", languages: ["Türkçe", "Hollandaca", "İngilizce"], specialties: ["Dahiliye", "İkinci görüş", "Kronik hastalık yönetimi"] },
  { id: "fatma-vize", name: "Fatma Güneş", role: "Vize & Göçmenlik Danışmanı", category: "Vize & Göçmenlik", country: "İngiltere", city: "Londra", rating: 4.8, reviews: 176, avatar: "FG", photo: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=400&h=400&fit=crop&crop=face", bio: "İngiltere vize ve oturum izni süreçlerinde 8 yıllık deneyim.", website: "https://fatmagunes.co.uk", whatsapp: "+447700000012", languages: ["Türkçe", "İngilizce"], specialties: ["Çalışma vizesi", "Aile birleşimi", "İltica süreçleri"] },
  { id: "osman-vize", name: "Osman Kılıç", role: "Vize & Göçmenlik Danışmanı", category: "Vize & Göçmenlik", country: "Kanada", city: "Toronto", rating: 4.9, reviews: 203, avatar: "OK", photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face", bio: "Kanada göçmenlik ve vatandaşlık süreçlerinde uzman.", website: "https://osmankilic.ca", whatsapp: "+14160000013", languages: ["Türkçe", "İngilizce"], specialties: ["Express Entry", "PNP programları", "Yatırımcı göçmenliği"] },
  { id: "derya-emlak", name: "Derya Aksoy", role: "Gayrimenkul Danışmanı", category: "Gayrimenkul", country: "BAE", city: "Dubai", rating: 4.8, reviews: 167, avatar: "DA", photo: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=400&h=400&fit=crop&crop=face", bio: "Dubai'de lüks konut ve ticari gayrimenkul yatırım danışmanlığı.", website: "https://deryaaksoy.ae", whatsapp: "+971500000014", languages: ["Türkçe", "İngilizce", "Arapça"], specialties: ["Lüks konut", "Off-plan projeler", "Kira yönetimi"] },
  { id: "hakan-emlak", name: "Hakan Yıldırım", role: "Gayrimenkul Danışmanı", category: "Gayrimenkul", country: "Almanya", city: "Münih", rating: 4.6, reviews: 98, avatar: "HY", photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop&crop=face", bio: "Münih'te Türk yatırımcılar için gayrimenkul danışmanlığı.", website: "https://hakanyildirim.de", whatsapp: "+491700000015", languages: ["Türkçe", "Almanca"], specialties: ["Konut yatırımı", "Ticari gayrimenkul", "Finansman danışmanlığı"] },
  { id: "nur-sirket", name: "Nur Başaran", role: "Şirket Kuruluşu Danışmanı", category: "Şirket & İş", country: "İngiltere", city: "Londra", rating: 4.7, reviews: 134, avatar: "NB", photo: "https://images.unsplash.com/photo-1588516903720-8ceb67f9ef84?w=400&h=400&fit=crop&crop=face", bio: "İngiltere'de Ltd şirket kuruluşu ve start-up danışmanlığı.", website: "https://nurbasaran.co.uk", whatsapp: "+447700000016", languages: ["Türkçe", "İngilizce"], specialties: ["Ltd şirket kuruluşu", "Muhasebe", "Start-up danışmanlığı"] },
  { id: "murat-sirket", name: "Murat Erdem", role: "Şirket Kuruluşu Danışmanı", category: "Şirket & İş", country: "Hollanda", city: "Amsterdam", rating: 4.8, reviews: 121, avatar: "ME", photo: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&h=400&fit=crop&crop=face", bio: "Hollanda'da BV kuruluşu ve vergi optimizasyonu.", website: "https://muraterdem.nl", whatsapp: "+316000000017", languages: ["Türkçe", "Hollandaca", "İngilizce"], specialties: ["BV kuruluşu", "KVK kaydı", "Vergi optimizasyonu"] },
  { id: "tugce-tasima", name: "Tuğçe Demir", role: "Eşya Taşıma & Lojistik", category: "Yaşam & Relocation", country: "Almanya", city: "Berlin", rating: 4.7, reviews: 89, avatar: "TD", photo: "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=400&h=400&fit=crop&crop=face", bio: "Türkiye-Almanya arası eşya taşıma ve gümrükleme.", website: "https://tugcedemir.de", whatsapp: "+491700000018", languages: ["Türkçe", "Almanca"], specialties: ["Uluslararası nakliyat", "Gümrükleme", "Evden eve taşıma"] },
  { id: "serkan-tasima", name: "Serkan Acar", role: "Eşya Taşıma & Lojistik", category: "Yaşam & Relocation", country: "İngiltere", city: "Londra", rating: 4.6, reviews: 72, avatar: "SA", photo: "https://images.unsplash.com/photo-1504257432389-52343af06ae3?w=400&h=400&fit=crop&crop=face", bio: "Türkiye-İngiltere eşya taşıma ve kargo hizmetleri.", website: "https://serkanacar.co.uk", whatsapp: "+447700000019", languages: ["Türkçe", "İngilizce"], specialties: ["Kargo hizmetleri", "Acil gönderim", "Depolama"] },
  { id: "baris-tasima", name: "Barış Koç", role: "Eşya Taşıma & Lojistik", category: "Yaşam & Relocation", country: "BAE", city: "Dubai", rating: 4.8, reviews: 105, avatar: "BK", photo: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=400&h=400&fit=crop&crop=face", bio: "Dubai-Türkiye arası taşımacılık ve lojistik.", website: "https://bariskoc.ae", whatsapp: "+971500000020", languages: ["Türkçe", "İngilizce", "Arapça"], specialties: ["Free zone depolama", "Lojistik çözümleri", "Uluslararası taşıma"] },
];

export const associations: Association[] = [
  // Dernekler & Vakıflar
  { id: "almanya-turk-toplumu", name: "Almanya Türk Toplumu", type: "Dernek", country: "Almanya", city: "Berlin", members: 12500, events: 45, description: "Almanya genelinde Türk toplulukları arasında köprü kurma, kültürel etkinlikler ve sosyal destek programları düzenleyen köklü dernek.", website: "https://att.de", founded: 1995, logo: "ATT" },
  { id: "ingiltere-turk-isadamlari", name: "İngiltere Türk İşadamları Derneği", type: "İş Örgütü", country: "İngiltere", city: "Londra", members: 3200, events: 28, description: "Londra merkezli Türk iş insanlarının networking, iş geliştirme ve yatırım fırsatları platformu.", website: "https://itid.co.uk", founded: 2005, logo: "İTİ" },
  { id: "hollanda-turk-vakfi", name: "Hollanda Türk Vakfı", type: "Vakıf", country: "Hollanda", city: "Amsterdam", members: 8700, events: 32, description: "Hollanda'daki Türk topluluğuna eğitim, kültür ve entegrasyon desteği sağlayan vakıf.", website: "https://htv.nl", founded: 1998, logo: "HTV" },
  { id: "bae-turk-dernegi", name: "BAE Türk İş ve Sosyal Dayanışma Derneği", type: "Sosyal Örgüt", country: "BAE", city: "Dubai", members: 5400, events: 38, description: "Dubai ve Abu Dhabi'de yaşayan Türk topluluğunu bir araya getiren dernek.", website: "https://baeturkler.ae", founded: 2010, logo: "BAE" },
  { id: "abd-turk-amerikan", name: "Türk Amerikan Dernekleri Federasyonu", type: "Dernek", country: "ABD", city: "Washington", members: 25000, events: 60, description: "ABD genelindeki Türk derneklerini çatı altında toplayan federasyon.", website: "https://tadf.org", founded: 1988, logo: "TAD" },
  { id: "fransa-turk-kulturu", name: "Fransa Türk Kültür Merkezi", type: "Vakıf", country: "Fransa", city: "Paris", members: 6100, events: 25, description: "Paris'te Türk kültürünü tanıtma ve kültürel köprü kurma misyonuyla çalışan merkez.", website: "https://ftkm.fr", founded: 2002, logo: "FTK" },
  // Türk Okulları
  { id: "berlin-turk-okulu", name: "Berlin Türk Okulu", type: "Okul", country: "Almanya", city: "Berlin", members: 850, events: 12, description: "Hafta sonu Türkçe dil ve kültür eğitimi veren okul. Çocuklar ve yetişkinler için kurslar.", website: "https://berlinturkokulu.de", founded: 2001, logo: "BTO" },
  { id: "londra-turk-egitim", name: "Londra Türk Eğitim Merkezi", type: "Okul", country: "İngiltere", city: "Londra", members: 1200, events: 18, description: "Londra'da Türkçe dil eğitimi, GCSE Türkçe hazırlık ve kültürel etkinlikler.", website: "https://lteg.co.uk", founded: 1998, logo: "LTE" },
  { id: "amsterdam-turk-okulu", name: "Amsterdam Türk Kültür Okulu", type: "Okul", country: "Hollanda", city: "Amsterdam", members: 620, events: 10, description: "Hollanda'da yaşayan Türk çocuklara Türkçe ve kültür eğitimi.", website: "https://atkokulu.nl", founded: 2005, logo: "ATK" },
  { id: "paris-turk-okulu", name: "Paris Türk Lisesi", type: "Okul", country: "Fransa", city: "Paris", members: 480, events: 8, description: "Paris'te MEB müfredatına uygun Türkçe eğitim veren lise.", website: "https://paristurklisesi.fr", founded: 2010, logo: "PTL" },
  { id: "dubai-turk-okulu", name: "Dubai Türk Okulu", type: "Okul", country: "BAE", city: "Dubai", members: 950, events: 15, description: "Dubai'de tam gün Türkçe eğitim veren uluslararası okul.", website: "https://dubaiturk.ae", founded: 2012, logo: "DTO" },
  // Türk Radyoları
  { id: "radyo-metropol-berlin", name: "Radyo Metropol FM", type: "Radyo", country: "Almanya", city: "Berlin", members: 45000, events: 6, description: "Almanya'nın en büyük Türkçe radyo istasyonu. Müzik, haberler ve söyleşiler.", website: "https://metropolfm.de", founded: 1999, logo: "MFM" },
  { id: "radyo-bizim-londra", name: "Bizim Radyo", type: "Radyo", country: "İngiltere", city: "Londra", members: 28000, events: 4, description: "Londra merkezli Türkçe radyo. Topluluk haberleri, müzik ve kültürel programlar.", website: "https://bizimradyo.co.uk", founded: 2006, logo: "BRM" },
  { id: "radyo-turku-hollanda", name: "Radyo Türkü", type: "Radyo", country: "Hollanda", city: "Amsterdam", members: 18000, events: 3, description: "Hollanda genelinde yayın yapan Türkçe radyo istasyonu.", website: "https://radyoturku.nl", founded: 2003, logo: "RTK" },
  // Türk TV Kanalları
  { id: "kanal-avrupa", name: "Kanal Avrupa", type: "TV Kanalı", country: "Almanya", city: "Frankfurt", members: 120000, events: 10, description: "Avrupa'daki Türk topluluğuna yönelik haber, kültür ve eğlence kanalı.", website: "https://kanalavrupa.de", founded: 2000, logo: "KAV" },
  { id: "turk-tv-uk", name: "Turkish TV UK", type: "TV Kanalı", country: "İngiltere", city: "Londra", members: 65000, events: 5, description: "İngiltere'deki Türk topluluğu için İngilizce ve Türkçe yayın yapan kanal.", website: "https://turkishtv.co.uk", founded: 2008, logo: "TTV" },
  { id: "eurostar-tv", name: "Euro Star TV", type: "TV Kanalı", country: "Hollanda", city: "Rotterdam", members: 85000, events: 7, description: "Benelüx bölgesindeki Türk topluluğuna yönelik televizyon kanalı.", website: "https://eurostartv.nl", founded: 2004, logo: "EST" },
  // Büyükelçilikler & Konsolosluklar
  { id: "tc-berlin-buyukelcilik", name: "T.C. Berlin Büyükelçiliği", type: "Büyükelçilik", country: "Almanya", city: "Berlin", members: 0, events: 12, description: "Türkiye Cumhuriyeti Berlin Büyükelçiliği. Konsolosluk hizmetleri, vize işlemleri, noter tasdiki ve vatandaşlık işlemleri.", website: "https://berlin.be.mfa.gov.tr", founded: 1952, logo: "🇹🇷" },
  { id: "tc-londra-baskonsolosluk", name: "T.C. Londra Başkonsolosluğu", type: "Konsolosluk", country: "İngiltere", city: "Londra", members: 0, events: 8, description: "Türkiye Cumhuriyeti Londra Başkonsolosluğu. Pasaport, nüfus, askerlik, noter ve vize hizmetleri.", website: "https://londra.bk.mfa.gov.tr", founded: 1949, logo: "🇹🇷" },
  { id: "tc-washington-buyukelcilik", name: "T.C. Washington Büyükelçiliği", type: "Büyükelçilik", country: "ABD", city: "Washington", members: 0, events: 10, description: "Türkiye Cumhuriyeti Washington Büyükelçiliği. Diplomatik ilişkiler ve vatandaş hizmetleri.", website: "https://washington.emb.mfa.gov.tr", founded: 1948, logo: "🇹🇷" },
  { id: "tc-dubai-baskonsolosluk", name: "T.C. Dubai Başkonsolosluğu", type: "Konsolosluk", country: "BAE", city: "Dubai", members: 0, events: 6, description: "Türkiye Cumhuriyeti Dubai Başkonsolosluğu. Konsolosluk hizmetleri ve ticaret ofisi.", website: "https://dubai.bk.mfa.gov.tr", founded: 2006, logo: "🇹🇷" },
];

export const whatsappGroups: WhatsAppGroup[] = [
  // Alumni
  { id: "odtu-almanya", name: "ODTÜ Mezunları Almanya", category: "alumni", country: "Almanya", city: "Berlin", members: 420, description: "ODTÜ mezunlarının Almanya'daki buluşma ve networking grubu", link: "https://chat.whatsapp.com/odtu-almanya", university: "ODTÜ" },
  { id: "odtu-ingiltere", name: "ODTÜ Mezunları İngiltere", category: "alumni", country: "İngiltere", city: "Londra", members: 310, description: "ODTÜ mezunlarının İngiltere networking grubu", link: "https://chat.whatsapp.com/odtu-uk", university: "ODTÜ" },
  { id: "bogazici-almanya", name: "Boğaziçi Mezunları Almanya", category: "alumni", country: "Almanya", city: "Münih", members: 385, description: "Boğaziçi Üniversitesi mezunlarının Almanya'daki grubu", link: "https://chat.whatsapp.com/bogazici-de", university: "Boğaziçi" },
  { id: "bogazici-bae", name: "Boğaziçi Mezunları Dubai", category: "alumni", country: "BAE", city: "Dubai", members: 275, description: "Boğaziçi mezunlarının Dubai networking grubu", link: "https://chat.whatsapp.com/bogazici-dubai", university: "Boğaziçi" },
  { id: "itu-almanya", name: "İTÜ Mezunları Almanya", category: "alumni", country: "Almanya", city: "Frankfurt", members: 290, description: "İstanbul Teknik Üniversitesi mezunlarının Almanya grubu", link: "https://chat.whatsapp.com/itu-de", university: "İTÜ" },
  { id: "itu-ingiltere", name: "İTÜ Mezunları İngiltere", category: "alumni", country: "İngiltere", city: "Londra", members: 210, description: "İTÜ mezunlarının İngiltere networking grubu", link: "https://chat.whatsapp.com/itu-uk", university: "İTÜ" },
  { id: "yildiz-almanya", name: "Yıldız Teknik Mezunları Almanya", category: "alumni", country: "Almanya", city: "Berlin", members: 180, description: "Yıldız Teknik Üniversitesi mezunları Almanya grubu", link: "https://chat.whatsapp.com/ytu-de", university: "Yıldız Teknik" },
  { id: "hacettepe-hollanda", name: "Hacettepe Mezunları Hollanda", category: "alumni", country: "Hollanda", city: "Amsterdam", members: 155, description: "Hacettepe Üniversitesi mezunları Hollanda grubu", link: "https://chat.whatsapp.com/hacettepe-nl", university: "Hacettepe" },
  { id: "bilkent-bae", name: "Bilkent Mezunları BAE", category: "alumni", country: "BAE", city: "Dubai", members: 195, description: "Bilkent Üniversitesi mezunlarının BAE grubu", link: "https://chat.whatsapp.com/bilkent-uae", university: "Bilkent" },
  { id: "koc-ingiltere", name: "Koç Üniversitesi Mezunları Londra", category: "alumni", country: "İngiltere", city: "Londra", members: 230, description: "Koç Üniversitesi mezunları İngiltere grubu", link: "https://chat.whatsapp.com/koc-uk", university: "Koç Üniversitesi" },
  // Hobi
  { id: "futbol-berlin", name: "Berlin Türk Futbol Grubu", category: "hobi", country: "Almanya", city: "Berlin", members: 340, description: "Berlin'deki Türk futbol severler için haftalık maç organizasyonu", link: "https://chat.whatsapp.com/futbol-berlin" },
  { id: "yemek-londra", name: "Londra Türk Yemek Kulübü", category: "hobi", country: "İngiltere", city: "Londra", members: 520, description: "Londra'da Türk mutfağı severler, yemek tarifleri ve restoran önerileri", link: "https://chat.whatsapp.com/yemek-london" },
  { id: "outdoor-munchen", name: "Münih Doğa & Hiking", category: "hobi", country: "Almanya", city: "Münih", members: 215, description: "Münih çevresinde doğa yürüyüşleri ve outdoor aktiviteler", link: "https://chat.whatsapp.com/hiking-munich" },
  { id: "kitap-dubai", name: "Dubai Türk Kitap Kulübü", category: "hobi", country: "BAE", city: "Dubai", members: 180, description: "Dubai'deki Türk kitapseverler için aylık okuma ve tartışma grubu", link: "https://chat.whatsapp.com/kitap-dubai" },
  { id: "fotograf-amsterdam", name: "Amsterdam Fotoğrafçılık Grubu", category: "hobi", country: "Hollanda", city: "Amsterdam", members: 145, description: "Amsterdam'da fotoğraf turları ve workshop'lar", link: "https://chat.whatsapp.com/foto-amsterdam" },
  // İş
  { id: "tech-berlin", name: "Berlin Türk Tech Network", category: "is", country: "Almanya", city: "Berlin", members: 680, description: "Berlin'deki Türk yazılımcı ve teknoloji profesyonelleri networking grubu", link: "https://chat.whatsapp.com/tech-berlin" },
  { id: "girisimci-londra", name: "Londra Türk Girişimciler", category: "is", country: "İngiltere", city: "Londra", members: 445, description: "Londra'daki Türk girişimciler için mentor ve yatırım ağı", link: "https://chat.whatsapp.com/girisimci-london" },
  { id: "finans-dubai", name: "Dubai Türk Finans Grubu", category: "is", country: "BAE", city: "Dubai", members: 310, description: "Dubai'deki Türk finans profesyonelleri networking grubu", link: "https://chat.whatsapp.com/finans-dubai" },
  { id: "saglik-almanya", name: "Almanya Türk Sağlık Profesyonelleri", category: "is", country: "Almanya", city: "Frankfurt", members: 290, description: "Almanya'daki Türk doktor, hemşire ve sağlık çalışanları", link: "https://chat.whatsapp.com/saglik-de" },
  { id: "hukuk-hollanda", name: "Hollanda Türk Hukukçular", category: "is", country: "Hollanda", city: "Amsterdam", members: 165, description: "Hollanda'daki Türk avukat ve hukuk profesyonelleri", link: "https://chat.whatsapp.com/hukuk-nl" },
];

export interface Business {
  id: string;
  name: string;
  sector: string;
  country: string;
  city: string;
  description: string;
  website: string;
  logo: string;
  founded: number;
  employees: number;
  offerings: ("iş ilanı" | "franchise" | "iş fırsatı")[];
  openPositions: number;
  contactEmail: string;
}

export const businesses: Business[] = [
  { id: "turkish-hospital-qatar", name: "Turkish Hospital Qatar", sector: "Sağlık", country: "Katar", city: "Doha", description: "Doha'da Türk doktorlar ve sağlık profesyonelleri tarafından kurulan tam donanımlı hastane. Uzman kadrosuyla bölgedeki Türk diasporasına ve yerel halka hizmet veriyor.", website: "https://turkishhospital.qa", logo: "THQ", founded: 2019, employees: 450, offerings: ["iş ilanı", "iş fırsatı"], openPositions: 25, contactEmail: "hr@turkishhospital.qa" },
  { id: "turkisch-doner-berlin", name: "Turkish Döner GmbH", sector: "Gastronomi", country: "Almanya", city: "Berlin", description: "Almanya genelinde 25 şubesiyle Türk döner ve fast-food zinciri. Franchise fırsatları sunuyoruz.", website: "https://turkishdoner.de", logo: "TDG", founded: 2008, employees: 320, offerings: ["franchise", "iş ilanı"], openPositions: 8, contactEmail: "franchise@turkishdoner.de" },
  { id: "anatolian-tech", name: "Anatolian Tech Solutions", sector: "Teknoloji", country: "İngiltere", city: "Londra", description: "Yazılım geliştirme ve dijital dönüşüm hizmetleri sunan Türk teknoloji firması.", website: "https://anatoliantech.co.uk", logo: "ATS", founded: 2015, employees: 85, offerings: ["iş ilanı", "iş fırsatı"], openPositions: 12, contactEmail: "hr@anatoliantech.co.uk" },
  { id: "istanbul-baklava", name: "İstanbul Baklava House", sector: "Gastronomi", country: "Hollanda", city: "Amsterdam", description: "Geleneksel Türk tatlıları ve baklava üretimi. Avrupa genelinde franchise veriyor.", website: "https://istanbulbaklava.nl", logo: "IBH", founded: 2012, employees: 45, offerings: ["franchise", "iş ilanı"], openPositions: 3, contactEmail: "info@istanbulbaklava.nl" },
  { id: "bosphorus-logistics", name: "Bosphorus Logistics", sector: "Lojistik", country: "Almanya", city: "Frankfurt", description: "Türkiye-Avrupa arası kargo ve lojistik çözümleri. Depo ve dağıtım ağı.", website: "https://bosphoruslog.de", logo: "BPL", founded: 2010, employees: 150, offerings: ["iş ilanı", "iş fırsatı"], openPositions: 6, contactEmail: "kariyer@bosphoruslog.de" },
  { id: "turkish-market-dubai", name: "Turkish Market UAE", sector: "Perakende", country: "BAE", city: "Dubai", description: "Dubai'de Türk gıda ürünleri ve market zinciri. Yeni şube açılışları için yatırımcı arıyor.", website: "https://turkishmarket.ae", logo: "TMU", founded: 2016, employees: 60, offerings: ["franchise", "iş fırsatı", "iş ilanı"], openPositions: 15, contactEmail: "invest@turkishmarket.ae" },
  { id: "ottoman-construction", name: "Ottoman Construction Ltd", sector: "İnşaat", country: "İngiltere", city: "Londra", description: "Konut ve ticari inşaat projeleri. Londra ve çevresinde aktif.", website: "https://ottomanconstruction.co.uk", logo: "OCL", founded: 2006, employees: 200, offerings: ["iş ilanı", "iş fırsatı"], openPositions: 10, contactEmail: "jobs@ottomanconstruction.co.uk" },
  { id: "cappadocia-travel", name: "Cappadocia Travel Group", sector: "Turizm", country: "Almanya", city: "Münih", description: "Türkiye turları ve seyahat organizasyonu. Acentelik fırsatları mevcut.", website: "https://cappadociatravel.de", logo: "CTG", founded: 2011, employees: 35, offerings: ["franchise", "iş ilanı"], openPositions: 4, contactEmail: "partner@cappadociatravel.de" },
  { id: "marmara-textil", name: "Marmara Textil AG", sector: "Tekstil", country: "Almanya", city: "Berlin", description: "Türk tekstil ürünlerinin Avrupa distribütörü. Toptan ve perakende.", website: "https://marmaratextil.de", logo: "MTA", founded: 2003, employees: 95, offerings: ["iş ilanı", "iş fırsatı"], openPositions: 5, contactEmail: "hr@marmaratextil.de" },
  { id: "sultans-cafe-paris", name: "Sultan's Café Paris", sector: "Gastronomi", country: "Fransa", city: "Paris", description: "Paris'te Türk kahvesi ve brunch konseptli kafe zinciri.", website: "https://sultanscafe.fr", logo: "SCP", founded: 2018, employees: 28, offerings: ["franchise", "iş ilanı"], openPositions: 6, contactEmail: "franchise@sultanscafe.fr" },
  // Loyalty partnerleri
  { id: "hsbc-turkey", name: "HSBC Türkiye", sector: "Finans", country: "İngiltere", city: "Londra", description: "HSBC diaspora bankacılık hizmetleri. Türk müşterilere özel döviz ve yatırım çözümleri.", website: "https://hsbc.com.tr", logo: "HSBC", founded: 1990, employees: 5000, offerings: ["iş ilanı", "iş fırsatı"], openPositions: 15, contactEmail: "diaspora@hsbc.com.tr" },
  { id: "thy-global", name: "Türk Hava Yolları", sector: "Havacılık", country: "Almanya", city: "Frankfurt", description: "THY diaspora özel uçuş kampanyaları ve mil kazanma fırsatları.", website: "https://turkishairlines.com", logo: "THY", founded: 1933, employees: 35000, offerings: ["iş ilanı", "iş fırsatı"], openPositions: 50, contactEmail: "hr@thy.com" },
  { id: "vodafone-de", name: "Vodafone Türk Hattı", sector: "Telekomünikasyon", country: "Almanya", city: "Berlin", description: "Vodafone Almanya diaspora özel hat ve roaming paketleri.", website: "https://vodafone.de", logo: "VDF", founded: 1992, employees: 12000, offerings: ["iş ilanı"], openPositions: 8, contactEmail: "karriere@vodafone.de" },
  { id: "turkish-market-chain", name: "Turkish Market Europe", sector: "Perakende", country: "Almanya", city: "Berlin", description: "Avrupa genelinde 120+ şube ile Türk gıda ürünleri market zinciri.", website: "https://turkishmarket.eu", logo: "TME", founded: 2005, employees: 2500, offerings: ["franchise", "iş ilanı"], openPositions: 35, contactEmail: "franchise@turkishmarket.eu" },
];

export const events: Event[] = [
  // Featured
  { id: "yatirim-webinari", title: "Avrupa'da Gayrimenkul Yatırım Fırsatları 2026", description: "Londra, Berlin ve Dubai'deki yatırım fırsatlarını uzman danışmanlarla değerlendirin. Piyasa analizi, vergi avantajları ve finansman seçenekleri detaylı anlatılacak.", date: "15 Mar 2026", time: "20:00", endTime: "22:00", country: "Almanya", city: "Online", location: "Zoom", type: "online", category: "iş", organizer: "Ayşe Kara", organizerType: "consultant", organizerAvatar: "AK", attendees: 245, maxAttendees: 500, price: 0, featured: true, image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=400&fit=crop", tags: ["Gayrimenkul", "Yatırım", "Webinar"] },
  { id: "diaspora-summit", title: "Türk Diaspora Zirvesi 2026", description: "Avrupa, Amerika ve Ortadoğu'dan Türk iş insanları, profesyoneller ve girişimcilerin buluştuğu yılın en büyük networking etkinliği.", date: "22 Nis 2026", time: "09:00", endTime: "18:00", country: "Almanya", city: "Berlin", location: "Berlin Congress Center", type: "yüz yüze", category: "networking", organizer: "Almanya Türk Toplumu", organizerType: "association", organizerAvatar: "ATT", attendees: 820, maxAttendees: 1200, price: 75, featured: true, image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=400&fit=crop", tags: ["Zirve", "Networking", "Diaspora"] },
  { id: "tech-meetup-london", title: "London Turkish Tech Meetup", description: "Londra'daki Türk yazılımcı ve teknoloji profesyonellerinin aylık buluşması. Bu ay konumuz: AI ve Startup Ekosistemi.", date: "08 Mar 2026", time: "18:30", endTime: "21:00", country: "İngiltere", city: "Londra", location: "WeWork Moorgate", type: "yüz yüze", category: "iş", organizer: "İngiltere Türk İşadamları Derneği", organizerType: "association", organizerAvatar: "İTİ", attendees: 85, maxAttendees: 120, price: 10, featured: true, image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=400&fit=crop", tags: ["Tech", "Meetup", "AI"] },
  // Regular
  { id: "vize-bilgilendirme", title: "Almanya Vize & Oturum İzni Bilgilendirme", description: "Almanya'da oturum izni, çalışma vizesi ve vatandaşlık süreçleri hakkında kapsamlı bilgilendirme.", date: "12 Mar 2026", time: "19:00", endTime: "20:30", country: "Almanya", city: "Online", location: "Google Meet", type: "online", category: "eğitim", organizer: "Mehmet Yılmaz", organizerType: "consultant", organizerAvatar: "MY", attendees: 156, maxAttendees: 300, price: 0, featured: false, image: "https://images.unsplash.com/photo-1569025743873-ea3a9ber4f83?w=800&h=400&fit=crop", tags: ["Vize", "Oturum", "Almanya"] },
  { id: "networking-yemegi", title: "İstanbul Lezzetleri - Networking Akşam Yemeği", description: "Berlin'deki Türk profesyoneller için lezzetli bir akşam yemeği eşliğinde networking fırsatı.", date: "18 Mar 2026", time: "19:30", endTime: "23:00", country: "Almanya", city: "Berlin", location: "Hasir Restaurant, Kreuzberg", type: "yüz yüze", category: "sosyal", organizer: "Almanya Türk Toplumu", organizerType: "association", organizerAvatar: "ATT", attendees: 42, maxAttendees: 60, price: 45, featured: false, image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&h=400&fit=crop", tags: ["Networking", "Yemek", "Sosyal"] },
  { id: "futbol-turnuvasi", title: "Türk Diaspora Futbol Turnuvası", description: "Berlin'deki Türk futbol takımları arasında dostluk turnuvası. Kayıt için takım kaptanları başvurabilir.", date: "05 Nis 2026", time: "10:00", endTime: "17:00", country: "Almanya", city: "Berlin", location: "Sportpark Neukölln", type: "yüz yüze", category: "spor", organizer: "Emre Aydın", organizerType: "member", organizerAvatar: "EA", attendees: 120, maxAttendees: 200, price: 15, featured: false, image: "https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=800&h=400&fit=crop", tags: ["Futbol", "Turnuva", "Spor"] },
  { id: "turk-filmleri", title: "Türk Film Gecesi - Kış Uykusu", description: "Aylık Türk film gösterimi. Bu ay Nuri Bilge Ceylan'ın ödüllü filmi Kış Uykusu.", date: "25 Mar 2026", time: "20:00", endTime: "23:00", country: "Hollanda", city: "Amsterdam", location: "Het Ketelhuis Cinema", type: "yüz yüze", category: "kültür", organizer: "Hollanda Türk Vakfı", organizerType: "association", organizerAvatar: "HTV", attendees: 65, maxAttendees: 100, price: 12, featured: false, image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&h=400&fit=crop", tags: ["Film", "Kültür", "Sinema"] },
  { id: "sirket-kurma-workshop", title: "Dubai'de Şirket Kurma Workshop", description: "Free zone vs mainland, lisans türleri, maliyetler ve banka hesap açma süreçleri hakkında uygulamalı workshop.", date: "02 Nis 2026", time: "14:00", endTime: "17:00", country: "BAE", city: "Dubai", location: "DTSO Merkez, JLT", type: "hybrid", category: "eğitim", organizer: "Zeynep Arslan", organizerType: "consultant", organizerAvatar: "ZA", attendees: 78, maxAttendees: 150, price: 25, featured: false, image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=400&fit=crop", tags: ["Şirket", "Dubai", "Workshop"] },
  { id: "cocuk-bayrami", title: "23 Nisan Çocuk Bayramı Kutlaması", description: "Çocuklar için oyunlar, yarışmalar, kültürel gösteriler ve geleneksel Türk yemekleri ile bayram kutlaması.", date: "23 Nis 2026", time: "11:00", endTime: "16:00", country: "İngiltere", city: "Londra", location: "Finsbury Park", type: "yüz yüze", category: "kültür", organizer: "Londra Türk Eğitim Merkezi", organizerType: "association", organizerAvatar: "LTE", attendees: 350, maxAttendees: 500, price: 0, featured: true, image: "https://images.unsplash.com/photo-1602631985686-1bb0e6a8696e?w=800&h=400&fit=crop", tags: ["23 Nisan", "Çocuk", "Bayram"] },
];
